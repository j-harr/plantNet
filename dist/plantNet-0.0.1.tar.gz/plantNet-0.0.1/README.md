# plantNet Package

This is the plantNet package. It is used for Raspberry Pi networking for imaging plants.
